export class Movie {
    id:any 
name:any
lang:any
info:any
genre:any
time:any
banner:any
bg_banner:any
status:any
price:any
}

