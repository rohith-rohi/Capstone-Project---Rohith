export class User {
        id :any
        firstName:string="";
         lastName:string="";
         phone:any
         address:string="";
         email:string="";
         username:string="";
         password:string="";

}
